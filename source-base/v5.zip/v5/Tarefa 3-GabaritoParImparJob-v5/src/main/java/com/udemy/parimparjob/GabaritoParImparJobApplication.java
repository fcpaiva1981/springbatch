package com.udemy.parimparjob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GabaritoParImparJobApplication {

	public static void main(String[] args) {
		SpringApplication.run(GabaritoParImparJobApplication.class, args);
	}

}
